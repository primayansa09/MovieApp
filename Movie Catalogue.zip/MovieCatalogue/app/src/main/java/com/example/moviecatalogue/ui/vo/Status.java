package com.example.moviecatalogue.ui.vo;

public enum Status {
    SUCCES,
    ERROR,
    LOADING
}
