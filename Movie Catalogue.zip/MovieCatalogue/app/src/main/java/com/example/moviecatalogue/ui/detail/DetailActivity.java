package com.example.moviecatalogue.ui.detail;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.resource.bitmap.RoundedCorners;
import com.bumptech.glide.request.RequestOptions;
import com.example.moviecatalogue.R;
import com.example.moviecatalogue.databinding.ActivityDetailBinding;
import com.example.moviecatalogue.ui.data.MovieEntity;
import com.example.moviecatalogue.ui.until.DataDummy;

public class DetailActivity extends AppCompatActivity {

    public static final String EXTRA_MODEL = "extra_model";

    private ActivityDetailBinding activityDetailBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        activityDetailBinding = ActivityDetailBinding.inflate(getLayoutInflater());
        setContentView(activityDetailBinding.getRoot());

        if (getSupportActionBar() != null){
            getSupportActionBar().setTitle("Detail Movie");
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        }

        DetailViewModel viewModel = new ViewModelProvider(this, new ViewModelProvider.NewInstanceFactory()).get(DetailViewModel.class);

        Bundle extra = getIntent().getExtras();
        if (extra != null){
            String dataMovie = extra.getString(EXTRA_MODEL);
            String dataTv = extra.getString(EXTRA_MODEL);
            if (dataMovie != null){

                viewModel.setSelectedMovie(dataMovie);
                detailMovie(viewModel.getMovies());

                for (int i = 0; i < DataDummy.generateDummyMovie().size(); i++){
                    MovieEntity movieEntity = DataDummy.generateDummyMovie().get(i);
                    if (movieEntity.getTitle().equals(dataMovie)){
                        detailMovie(movieEntity);
                        showProgreeBar(false);
                    }
                }

                for (int i = 0; i < DataDummy.generateDummyTv().size(); i++){
                    MovieEntity tvEntity = DataDummy.generateDummyTv().get(i);
                    if (tvEntity.getTitle().equals(dataTv)){
                        detailMovie(tvEntity);
                        showProgreeBar(false);
                    }
                }
            }

        }

        activityDetailBinding.toolbarDetail.imgBackDetail.setOnClickListener(v -> {
            finish();
        });

        sahreOnClik();

    }

    private void detailMovie(MovieEntity movieEntity) {
        activityDetailBinding.tvTitleDetail.setText(movieEntity.getTitle());
        activityDetailBinding.tvDescDetail.setText(movieEntity.getDescription());
        activityDetailBinding.tvDurationDetail.setText(movieEntity.getDuration());
        activityDetailBinding.tvCategoryDetail.setText(movieEntity.getCategory());
        activityDetailBinding.tvReleaseDetail.setText(movieEntity.getRelease());

        Glide.with(this)
                .load(movieEntity.getImage())
                .transform(new RoundedCorners(20))
                .apply(RequestOptions.placeholderOf(R.drawable.ic_loading)
                                    .error(R.drawable.ic_error))
                .into(activityDetailBinding.imgDetail);
    }

    private void sahreOnClik() {
        activityDetailBinding.imgShare.setOnClickListener(v -> {
            Intent share = new Intent();
            share.setAction(Intent.ACTION_SEND);
            share.putExtra(Intent.EXTRA_TEXT,activityDetailBinding.tvTitleDetail.getText().toString() +"\n"+
                    activityDetailBinding.tvReleaseDetail.getText().toString() +"\n"+ activityDetailBinding.tvDurationDetail.getText().toString()+"\n"+
                    activityDetailBinding.tvCategoryDetail.getText().toString()+"\n"+ activityDetailBinding.tvDescDetail.getText().toString());
            share.setType("text/plain");

            Intent shareIntent = Intent.createChooser(share, "Bagikan Film ini Sekarang");
            startActivity(shareIntent);
        });
    }

    private void showProgreeBar(Boolean state){
        if (state){
            activityDetailBinding.progreeBarDetail.setVisibility(View.VISIBLE);
        }else {
            activityDetailBinding.progreeBarDetail.setVisibility(View.GONE);
        }
    }
}