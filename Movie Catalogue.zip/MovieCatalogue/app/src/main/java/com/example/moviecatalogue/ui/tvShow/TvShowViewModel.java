package com.example.moviecatalogue.ui.tvShow;

import androidx.lifecycle.ViewModel;

import com.example.moviecatalogue.ui.data.MovieEntity;
import com.example.moviecatalogue.ui.until.DataDummy;
import java.util.List;

public class TvShowViewModel extends ViewModel {
    List<MovieEntity> getTvShows(){
        return DataDummy.generateDummyTv();
    }
}
