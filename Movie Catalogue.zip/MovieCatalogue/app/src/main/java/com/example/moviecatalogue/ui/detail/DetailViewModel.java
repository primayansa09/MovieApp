package com.example.moviecatalogue.ui.detail;

import androidx.lifecycle.ViewModel;
import com.example.moviecatalogue.ui.data.MovieEntity;
import com.example.moviecatalogue.ui.until.DataDummy;
import java.util.ArrayList;
import java.util.List;

public class DetailViewModel extends ViewModel {
    private String movieId;

    public void setSelectedMovie(String movieId){
        this.movieId = movieId;
    }

   public MovieEntity getMovies(){
        MovieEntity movies =null;
        List<MovieEntity> movieEntities = DataDummy.generateDummyMovie();
        for (MovieEntity movieEntity : movieEntities){
            if (movieEntity.getTitle().equals(movieId)){
                movies = movieEntity;
            }
        }

        ArrayList<MovieEntity> tvEntities = DataDummy.generateDummyTv();
        for (MovieEntity tvEntity : tvEntities){
            if (tvEntity.getTitle().equals(movieId)){
                movies = tvEntity;
            }
        }
        return movies;
   }
}
