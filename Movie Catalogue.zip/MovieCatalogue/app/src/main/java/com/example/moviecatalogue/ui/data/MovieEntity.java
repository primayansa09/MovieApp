package com.example.moviecatalogue.ui.data;

import android.os.Parcel;
import android.os.Parcelable;
import java.util.ArrayList;

public class MovieEntity extends ArrayList<MovieEntity> implements Parcelable {
    private int id;
    private String title;
    private String description;
    private String category;
    private String release;
    private String duration;
    private String image;

    public MovieEntity(int id, String title, String description, String category, String release, String duration, String image){
        this.id = id;
        this.title = title;
        this.description = description;
        this.category = category;
        this.release = release;
        this.duration = duration;
        this.image = image;
    }

    protected MovieEntity(Parcel in) {
        id = in.readInt();
        title = in.readString();
        description = in.readString();
        category = in.readString();
        release = in.readString();
        duration = in.readString();
        image = in.readString();
    }

    public static final Creator<MovieEntity> CREATOR = new Creator<MovieEntity>() {
        @Override
        public MovieEntity createFromParcel(Parcel in) {
            return new MovieEntity(in);
        }

        @Override
        public MovieEntity[] newArray(int size) {
            return new MovieEntity[size];
        }
    };

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getRelease() {
        return release;
    }

    public void setRelease(String release) {
        this.release = release;
    }

    public String getDuration() {
        return duration;
    }

    public void setDuration(String duration) {
        this.duration = duration;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeInt(id);
        dest.writeString(title);
        dest.writeString(description);
        dest.writeString(category);
        dest.writeString(release);
        dest.writeString(duration);
        dest.writeString(image);
    }
}
