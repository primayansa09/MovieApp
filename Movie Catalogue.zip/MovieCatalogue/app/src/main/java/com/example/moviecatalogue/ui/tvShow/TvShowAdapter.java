package com.example.moviecatalogue.ui.tvShow;

import android.content.Intent;
import android.view.LayoutInflater;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;
import com.example.moviecatalogue.R;
import com.example.moviecatalogue.databinding.ItemListBinding;
import com.example.moviecatalogue.ui.data.MovieEntity;
import com.example.moviecatalogue.ui.detail.DetailActivity;
import java.util.ArrayList;
import java.util.List;

public class TvShowAdapter extends RecyclerView.Adapter<TvShowAdapter.TvViewHolder> {

    private final List<MovieEntity> listTv = new ArrayList<>();

    public void setTvModel(List<MovieEntity> listTv){
        if (listTv == null) return;
        this.listTv.clear();
        this.listTv.addAll(listTv);
    }

    @NonNull
    @Override
    public TvViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        ItemListBinding binding = ItemListBinding.inflate(LayoutInflater.from(parent.getContext()), parent, false);
        return new TvViewHolder(binding);
    }

    @Override
    public void onBindViewHolder(@NonNull TvViewHolder holder, int position) {
        MovieEntity tvShowEntity = listTv.get(position);
        holder.bind(tvShowEntity);
    }

    @Override
    public int getItemCount() {
        return listTv.size();
    }

    public class TvViewHolder extends RecyclerView.ViewHolder {

        private ItemListBinding binding;

        public TvViewHolder(ItemListBinding binding) {
            super(binding.getRoot());
            this.binding = binding;
        }

        void bind(MovieEntity tvShow){
            binding.tvTitleMovie.setText(tvShow.getTitle());
            binding.tvReleaseDate.setText(tvShow.getRelease());
            binding.tvCategory.setText(tvShow.getCategory());
            itemView.setOnClickListener(v -> {
                Intent intent = new Intent(itemView.getContext(), DetailActivity.class);
                intent.putExtra(DetailActivity.EXTRA_MODEL, tvShow.getTitle());
                itemView.getContext().startActivity(intent);
            });

            Glide.with(itemView.getContext())
                    .load(tvShow.getImage())
                    .apply(RequestOptions.placeholderOf(R.drawable.ic_loading).error(R.drawable.ic_error))
                    .into(binding.imgMovie);
        }
    }
}
