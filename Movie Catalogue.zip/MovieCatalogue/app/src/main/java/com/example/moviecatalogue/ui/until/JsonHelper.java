package com.example.moviecatalogue.ui.until;

import android.content.Context;

public class JsonHelper {

    private Context context;

    public JsonHelper(Context context){
        this.context = context;
    }

}
