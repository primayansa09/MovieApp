package com.example.moviecatalogue.ui.data.remote;

public enum StatusResponse {
    SUCCESS,
    EMPTY,
    ERROR
}
