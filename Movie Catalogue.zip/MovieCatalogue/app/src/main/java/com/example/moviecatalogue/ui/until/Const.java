package com.example.moviecatalogue.ui.until;

public class Const {
    //URL
    public static final String MOVIE_ID = "634649";
    public static final String TVSHOW_ID = "85552";
    public static final String URL_MOVIE = "discover/movie";
    public static final String URL_TVSHOW = "discover/tv";
    public static final String BASE_IMAGE_URL = "https://image.tmdb.org/t/p/w500";
    public static final String BASE_URL = "https://api.themoviedb.org/3/";

    //API
    public static final String API_KEY = "114147cbe78d94d18db52fbed1023d6d";

    //SPLASH SCREEN
    public static final int DELAY_SPLASH_SCREEN = 3000;
}
