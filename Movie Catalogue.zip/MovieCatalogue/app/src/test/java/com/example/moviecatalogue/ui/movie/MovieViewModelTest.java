package com.example.moviecatalogue.ui.movie;

import static org.junit.Assert.*;

import com.example.moviecatalogue.ui.data.MovieEntity;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class MovieViewModelTest {
    private MovieViewModel viewModel;

    @Before
    public void setUp(){
        viewModel = new MovieViewModel();
    }

    @Test
    public void getMovies() {
        List<MovieEntity> movieEntities = viewModel.getMovies();
        assertNotNull(movieEntities);
        assertEquals(10, movieEntities.size());
    }
}