package com.example.moviecatalogue.ui.tvShow;

import static org.junit.Assert.*;

import com.example.moviecatalogue.ui.data.MovieEntity;

import org.junit.Before;
import org.junit.Test;

import java.util.List;

public class TvShowViewModelTest {
    private TvShowViewModel viewModel;

    @Before
    public void setUp(){
        viewModel = new TvShowViewModel();
    }

    @Test
    public void getTvShows() {
        List<MovieEntity> tvEntities = viewModel.getTvShows();
        assertNotNull(tvEntities);
        assertEquals(10, tvEntities.size());
    }
}